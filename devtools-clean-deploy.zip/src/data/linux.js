export default [
  { command: "ls -la", description: "List files with detailed info" },
  { command: "cd ~", description: "Go to home directory" },
  { command: "pwd", description: "Print current directory" },
  { command: "rm -rf folder", description: "Force delete a folder" }
];
