export default [
  { command: "npm init -y", description: "Create package.json with defaults" },
  { command: "npm install package", description: "Install a package" },
  { command: "npm run dev", description: "Run development script" }
];
