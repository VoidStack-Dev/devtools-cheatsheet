export default [
  { command: "ssh user@host", description: "Connect to remote server" },
  { command: "ssh-keygen -t rsa", description: "Generate SSH key" }
];
